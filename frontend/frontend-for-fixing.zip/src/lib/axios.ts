import axios from 'axios';

// Get API URL from environment variables or use proxy in development
const isDevelopment = import.meta.env.DEV;
const API_URL = isDevelopment ? '' : import.meta.env.VITE_API_URL;

if (!isDevelopment && !API_URL) {
  console.error('VITE_API_URL is not defined in environment variables and not in development mode');
}

// In development, use the proxy to route to localhost:8080 (backend-go default port)
// Ensure no trailing slashes to avoid backend redirects
const baseURL = isDevelopment ? '/api/v1' : `${API_URL}/api/v1`;
console.log('Using API base URL:', baseURL);

// Create axios instance with configuration
const api = axios.create({
  baseURL: baseURL,
  headers: {
    'Accept': 'application/json',
    'Content-Type': 'application/json'
  },
  // Include credentials for CORS requests
  withCredentials: false,
  timeout: 30000 // 30 second timeout
});

// Function to get fresh token from localStorage
const getAuthToken = () => {
  return localStorage.getItem('token');
};

// Configure request interceptor to include authentication token
api.interceptors.request.use(
  (config) => {
    const token = getAuthToken();
    
    // Always get fresh token from storage
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    // Remove trailing slash logic as backend normalizes URLs
    // No need to add trailing slashes as the backend will handle normalization
    
    return config;
  },
  (error) => {
    console.error('Request configuration error:', error);
    return Promise.reject(error);
  }
);

// Configure response interceptor for error handling
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    // Log detailed error information
    console.error('API Error:', {
      status: error.response?.status,
      url: error.config?.url,
      method: error.config?.method,
      message: error.message,
      data: error.response?.data
    });

    // Handle different error types
    switch (error.response?.status) {
      case 401:
        // Handle unauthorized - redirect to login unless it's an auth endpoint
        if (!error.config?.url?.includes('/auth/')) {
          localStorage.removeItem('token');
          delete api.defaults.headers.common['Authorization'];
          // Use window.location.replace to avoid back button issues
          window.location.replace('/login');
        }
        break;
      
      case 403:
        // Handle forbidden
        console.error('Permission denied:', error.response?.data?.message || error.response?.data?.detail);
        break;
      
      case 404:
        // Handle not found
        console.error('Resource not found:', error.config?.url);
        break;
      
      case 422:
        // Handle validation errors (common in backend-go)
        console.error('Validation error:', error.response?.data?.message || error.response?.data?.errors);
        break;
      
      case 500:
        // Handle server errors
        console.error('Server error:', error.response?.data?.message);
        break;
    }

    return Promise.reject(error);
  }
);

// Export both named and default exports for flexibility
export { api };
export default api;


