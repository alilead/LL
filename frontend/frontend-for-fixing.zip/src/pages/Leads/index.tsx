import { LeadList } from './LeadList';

export function LeadsPage() {
  return <LeadList />;
}
